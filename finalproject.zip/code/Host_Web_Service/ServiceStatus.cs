﻿using System;
namespace Host_Web_Service.Properties
{
    public class ServiceStatus
    {
        public string Status { get; set; } = "Stopped";
    }
}