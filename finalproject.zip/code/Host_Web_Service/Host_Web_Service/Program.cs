var builder = WebApplication.CreateBuilder(args);

// 1. Add CORS services and define a policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowALL", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.AddControllers();

// ? Add Swagger services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// ? Enable Swagger middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 2. Use CORS middleware
app.UseCors("AllowALL");

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
