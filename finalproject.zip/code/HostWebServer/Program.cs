﻿var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowALL", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

app.UseHttpsRedirection();

// Serve static files from wwwroot (with default index.html)
app.UseDefaultFiles();       // <-- Important
app.UseStaticFiles();        // <-- Already added

app.UseCors("AllowALL");

app.UseRouting();

app.UseAuthorization();

// Set up controller routing
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
