﻿const baseUrl = 'https://localhost:7179/api/ServiceStatus';
let pollInterval = null;
let lastLoggedData = ''; // To avoid logging the same data repeatedly

async function fetchStatus() {
    try {
        const response = await fetch(`${baseUrl}/status`);
        const data = await response.json();

        document.getElementById('statusView').innerText = `Status: ${data.status}`;

        if (data.data && data.data !== lastLoggedData) {
            const resultBox = document.getElementById('resultView');
            const timestamp = new Date().toLocaleTimeString();
            resultBox.value += `[${timestamp}] ${data.data}\n`;
            resultBox.scrollTop = resultBox.scrollHeight; // Auto-scroll to bottom

            lastLoggedData = data.data; // Update last seen
        }

    } catch (error) {
        document.getElementById('statusView').innerText = 'Status: Error';
        const resultBox = document.getElementById('resultView');
        const timestamp = new Date().toLocaleTimeString();
        resultBox.value += `[${timestamp}] Error fetching data\n`;
    }
}

async function startService() {
    try {
        const response = await fetch(`${baseUrl}/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();

        const resultBox = document.getElementById('resultView');
        const timestamp = new Date().toLocaleTimeString();
        resultBox.value += `[${timestamp}] ${data.message}\n`;
        resultBox.scrollTop = resultBox.scrollHeight;

        pollInterval = setInterval(fetchStatus, 2000);
        fetchStatus();
    } catch (error) {
        const resultBox = document.getElementById('resultView');
        resultBox.value += `[Error] ${error.message}\n`;
    }
}

async function stopService() {
    try {
        const response = await fetch(`${baseUrl}/stop`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();

        const resultBox = document.getElementById('resultView');
        const timestamp = new Date().toLocaleTimeString();
        resultBox.value += `[${timestamp}] ${data.message}\n`;
        resultBox.scrollTop = resultBox.scrollHeight;

        clearInterval(pollInterval);
    } catch (error) {
        const resultBox = document.getElementById('resultView');
        resultBox.value += `[Error] ${error.message}\n`;
    }
}
