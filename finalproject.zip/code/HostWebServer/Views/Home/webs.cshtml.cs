using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HostWebServer.Views.Home
{
    public class websModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
